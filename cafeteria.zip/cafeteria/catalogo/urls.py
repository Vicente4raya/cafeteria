from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('catalogo/', views.catalogo, name='catalogo'),
    path('cliente/', views.cliente_dashboard, name='cliente_dashboard'),
    path('encargado/', views.encargado_dashboard, name='encargado_dashboard'),

    # Gestión de Categorías
    path('gestion/categorias/', views.categoria_list, name='categoria_list'),
    path('gestion/categorias/nueva/', views.categoria_create, name='categoria_create'),
    path('gestion/categorias/<int:pk>/', views.categoria_detail, name='categoria_detail'),
    path('gestion/categorias/<int:pk>/editar/', views.categoria_update, name='categoria_update'),
    path('gestion/categorias/<int:pk>/eliminar/', views.categoria_delete, name='categoria_delete'),

    # Gestión de Productos
    path('gestion/productos/', views.producto_list, name='producto_list'),
    path('gestion/productos/nuevo/', views.producto_create, name='producto_create'),
    path('gestion/productos/<int:pk>/', views.producto_detail, name='producto_detail'),
    path('gestion/productos/<int:pk>/editar/', views.producto_update, name='producto_update'),
    path('gestion/productos/<int:pk>/eliminar/', views.producto_delete, name='producto_delete'),
]
