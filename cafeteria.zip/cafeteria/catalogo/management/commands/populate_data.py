from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from catalogo.models import Categoria, Producto, Cliente, Encargado

class Command(BaseCommand):
    help = 'Populate the database with initial data'

    def handle(self, *args, **kwargs):
        # Create categories
        categorias = [
            Categoria.objects.create(nombre=f"Categoría {i}", descripcion=f"Descripción {i}")
            for i in range(1, 5)
        ]

        # Create products
        for i in range(1, 21):
            Producto.objects.create(
                nombre=f"Producto {i}",
                descripcion=f"Descripción del producto {i}",
                precio=10.0 + i,
                categoria=categorias[i % 4]
            )

        # Create users
        encargado_user = User.objects.create_user(username='encargado', password='password123')
        cliente1_user = User.objects.create_user(username='cliente1', password='password123')
        cliente2_user = User.objects.create_user(username='cliente2', password='password123')

        # Create encargado and clients
        Encargado.objects.create(usuario=encargado_user, puesto='Encargado General')
        Cliente.objects.create(usuario=cliente1_user, direccion='Dirección Cliente 1')
        Cliente.objects.create(usuario=cliente2_user, direccion='Dirección Cliente 2')

        self.stdout.write(self.style.SUCCESS('Database populated successfully!'))