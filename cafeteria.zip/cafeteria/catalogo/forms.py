from django import forms
from .models import Categoria, Producto

class CategoriaForm(forms.ModelForm):
    class Meta:
        model = Categoria
        fields = ['nombre', 'descripcion']
        labels = {
            'nombre': 'Nombre de la categoría',
            'descripcion': 'Descripción',
        }

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['codigo', 'nombre', 'descripcion', 'precio', 'categoria', 'stock', 'disponible']
        labels = {
            'codigo': 'Código único',
            'nombre': 'Nombre del producto',
            'descripcion': 'Descripción',
            'precio': 'Precio ($)',
            'categoria': 'Categoría',
            'stock': 'Stock disponible',
            'disponible': 'Disponible para la venta',
        }
