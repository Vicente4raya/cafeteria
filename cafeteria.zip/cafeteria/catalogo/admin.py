from django.contrib import admin
from .models import Categoria, Producto, Cliente, Encargado, Pedido, DetallePedido

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    search_fields = ['nombre']
    list_display = ['id', 'nombre', 'descripcion']


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    search_fields = ['nombre']
    list_filter = ['categoria']
    list_display = ['id', 'nombre', 'precio', 'categoria', 'stock']


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    search_fields = ['usuario__username']
    list_display = ['id', 'usuario', 'direccion']


@admin.register(Encargado)
class EncargadoAdmin(admin.ModelAdmin):
    search_fields = ['usuario__username']
    list_display = ['id', 'usuario', 'puesto']


class DetallePedidoInline(admin.TabularInline):
    model = DetallePedido
    extra = 1


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    search_fields = ['cliente__usuario__username']
    list_filter = ['fecha']
    list_display = ['id', 'cliente', 'encargado', 'fecha', 'total']
    inlines = [DetallePedidoInline]