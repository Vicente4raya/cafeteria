from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden
from django.db.models import Q, ProtectedError
from django.contrib import messages
from .models import Pedido, Producto, Categoria
from .forms import CategoriaForm, ProductoForm

# --- VISTAS EXISTENTES ---

@login_required
def catalogo(request):
    query = request.GET.get('q', '')
    categoria_id = request.GET.get('categoria', '')

    productos = Producto.objects.filter(disponible=True, stock__gt=0, categoria__isnull=False)

    if query:
        productos = productos.filter(Q(nombre__icontains=query) | Q(codigo__icontains=query))

    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)

    categorias = Categoria.objects.all()

    return render(request, 'catalogo/catalogo.html', {
        'productos': productos,
        'categorias': categorias,
        'query': query,
        'categoria_id': categoria_id,
    })

@login_required
def home(request):
    if request.user.is_staff:
        return redirect('encargado_dashboard')
    else:
        return redirect('cliente_dashboard')

@login_required
def cliente_dashboard(request):
    if request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    pedidos = Pedido.objects.filter(cliente__usuario=request.user)
    return render(request, 'catalogo/cliente_dashboard.html', {'pedidos': pedidos})

@login_required
def encargado_dashboard(request):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    pedidos = Pedido.objects.filter(encargado__usuario=request.user)
    return render(request, 'catalogo/encargado_dashboard.html', {'pedidos': pedidos})


# --- CRUD DE CATEGORÍAS (SOLO ENCARGADO) ---

@login_required
def categoria_list(request):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    categorias = Categoria.objects.all().order_by('nombre')
    return render(request, 'catalogo/categoria_list.html', {'categorias': categorias})

@login_required
def categoria_detail(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    categoria = get_object_or_404(Categoria, pk=pk)
    productos = categoria.productos.all()
    return render(request, 'catalogo/categoria_detail.html', {
        'categoria': categoria,
        'productos': productos
    })

@login_required
def categoria_create(request):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    if request.method == 'POST':
        form = CategoriaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Categoría creada correctamente.")
            return redirect('categoria_list')
    else:
        form = CategoriaForm()
    return render(request, 'catalogo/categoria_form.html', {'form': form, 'accion': 'Crear'})

@login_required
def categoria_update(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        form = CategoriaForm(request.POST, instance=categoria)
        if form.is_valid():
            form.save()
            messages.success(request, "Categoría actualizada correctamente.")
            return redirect('categoria_list')
    else:
        form = CategoriaForm(instance=categoria)
    return render(request, 'catalogo/categoria_form.html', {'form': form, 'accion': 'Editar'})

@login_required
def categoria_delete(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    categoria = get_object_or_404(Categoria, pk=pk)
    if request.method == 'POST':
        try:
            categoria.delete()
            messages.success(request, "Categoría eliminada correctamente.")
            return redirect('categoria_list')
        except ProtectedError:
            messages.error(request, "No se puede eliminar la categoría porque tiene productos asociados.")
            return redirect('categoria_list')
    return render(request, 'catalogo/categoria_confirm_delete.html', {'categoria': categoria})


# --- CRUD DE PRODUCTOS (SOLO ENCARGADO) ---

@login_required
def producto_list(request):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    
    productos = Producto.objects.select_related('categoria').all().order_by('nombre')
    
    q = request.GET.get('q', '').strip()
    categoria_id = request.GET.get('categoria', '')
    disponible = request.GET.get('disponible', '')

    # Buscar por nombre o código
    if q:
        productos = productos.filter(Q(nombre__icontains=q) | Q(codigo__icontains=q))
    
    # Filtrar por categoría
    if categoria_id:
        productos = productos.filter(categoria_id=categoria_id)
    
    # Filtrar por disponibilidad
    if disponible == '1':
        productos = productos.filter(disponible=True)
    elif disponible == '0':
        productos = productos.filter(disponible=False)

    categorias = Categoria.objects.all()

    return render(request, 'catalogo/producto_list.html', {
        'productos': productos,
        'categorias': categorias,
        'q': q,
        'categoria_id': categoria_id,
        'disponible': disponible,
    })

@login_required
def producto_detail(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    producto = get_object_or_404(Producto, pk=pk)
    return render(request, 'catalogo/producto_detail.html', {'producto': producto})

@login_required
def producto_create(request):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Producto creado correctamente.")
            return redirect('producto_list')
    else:
        form = ProductoForm()
    return render(request, 'catalogo/producto_form.html', {'form': form, 'accion': 'Crear'})

@login_required
def producto_update(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            messages.success(request, "Producto actualizado correctamente.")
            return redirect('producto_list')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'catalogo/producto_form.html', {'form': form, 'accion': 'Editar'})

@login_required
def producto_delete(request, pk):
    if not request.user.is_staff:
        return HttpResponseForbidden("No tienes permiso para acceder a esta página.")
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        producto.delete()
        messages.success(request, "Producto eliminado correctamente.")
        return redirect('producto_list')
    return render(request, 'catalogo/producto_confirm_delete.html', {'producto': producto})
